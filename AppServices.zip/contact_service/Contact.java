// Briana Long
// CS 320
// 6/15/24
//
// Contact class that creates character limits in contact fields


public class Contact{
	private String contactId;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	// Sets arguments for contact lengths
	public Contact(String contactId, String firstName, String lastName, String number, Sring address) {
		 if (contactId == null || contactId.length() > 10) {
	            throw new IllegalArgumentException("Invalid contact ID");
	        }
	        if (firstName == null || firstName.length() > 10) {
	            throw new IllegalArgumentException("Invalid first name");
	        }
	        if (lastName == null || lastName.length() > 10) {
	            throw new IllegalArgumentException("Invalid last name");
	        }
	        if (number == null || number.length() != 10) {
	            throw new IllegalArgumentException("Invalid phone number");
	        }
	        if (address == null || address.length() > 30) {
	            throw new IllegalArgumentException("Invalid address");
	        }
	        
	        //Gets information
	        this.contactId = contactId;
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.number = number;
	        this.address = address;
	    }
	//Sets lengths for each part of the contact ID
    public String getContactId() {
        return contactId;
    }
    
    //first name
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }
    
    //last name
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }
    
    //number
    public String getnumber() {
        return number;
    }

    public void setnumber(String number) {
        if (number == null || number.length() != 10) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        this.number = number;
    }

    // address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
	}
}