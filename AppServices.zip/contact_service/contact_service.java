// Briana Long
// CS 320
// 6/15/24
//
// Contact service that can add, delete and update contact fields

import java.util.HashMap;
import java.util.Map;


//Contact Service class
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    //add Contact
    //if exists already throw illegal argument
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // delete
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    // update first
    public void updateContactFirstName(String contactId, String firstName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setFirstName(firstName);
        }
    }

    // update last
    public void updateContactLastName(String contactId, String lastName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setLastName(lastName);
        }
    }

    //update number
    public void updateContactNumber(String contactId, String number) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setNumber(number);
        }
    }

    //update address
    public void updateContactAddress(String contactId, String address) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setAddress(address);
        }
    }

    // get contact
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}