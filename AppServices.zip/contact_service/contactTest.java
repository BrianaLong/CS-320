// Briana Long
// CS 320
// 6/15/24
//
// Contact Test that creates character limits in contact fields


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class contactTest {

	public class ContactTest {

	    @Test
	    @DisplayName("Valid creation")
	    public void testValidContactCreation() {
	        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
	        assertEquals("1", contact.getContactId());
	        assertEquals("John", contact.getFirstName());
	        assertEquals("Doe", contact.getLastName());
	        assertEquals("1234567890", contact.getNumber());
	        assertEquals("123 Main St", contact.getAddress());
	    }


	    @Test
	    @DisplayName("ID too long")
	    public void testContactIdTooLong() {
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
	        });
	        assertEquals("Invalid contact ID", exception.getMessage());
	    }


	    @Test
	    @DisplayName("First name too long")
	    public void testFirstNameTooLong() {
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("1", "Johnathan123", "Doe", "1234567890", "123 Main St");
	        });
	        assertEquals("Invalid first name", exception.getMessage());
	    }


	    @Test
	    @DisplayName("Last name too long")
	    public void testLastNameTooLong() {
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("1", "John", "Doenamethatistoolong", "1234567890", "123 Main St");
	        });
	        assertEquals("Invalid last name", exception.getMessage());
	    }

	    
	    @Test
	    @DisplayName("Number invalid")
	    public void testNumberInvalidLength() {
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("1", "John", "Doe", "12345", "123 Main St");
	        });
	        assertEquals("Invalid phone number", exception.getMessage());
	    }


	    @Test
	    @DisplayName("Address too long")
	    public void testAddressTooLong() {
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            new Contact("1", "John", "Doe", "1234567890", "123 Main St that has a very very long address");
	        });
	        assertEquals("Invalid address", exception.getMessage());
	    }


	    @Test
	    @DisplayName("last name too long")
	    public void testSetLastNameTooLong() {
	        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            contact.setLastName("Smithsonian123");
	        });
	        assertEquals("Invalid last name", exception.getMessage());
	    }


	    @Test
	    @DisplayName("Number is too long")
	    public void testSetNumberInvalidLength() {
	        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
	        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
	            contact.setNumber("09876");
	        });
	        assertEquals("Invalid phone number", exception.getMessage());
	    }

	}

}
