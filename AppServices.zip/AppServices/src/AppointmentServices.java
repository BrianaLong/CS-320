//Briana Long
//CS320
//6/16/24
//
// Appointment class for the adding and deleting of appointments

import java.util.HashMap;
import java.util.Map;

public class AppointmentServices {

	private final Map<String, Appointment> appointments = new HashMap<>();
	
	// argument for duplicate ID
	public void addAppointment(Appointment appointment) {
		if (appointments.conatinsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Appointment ID already exists");
		}
		appointments.put(appointment.getAppointmentId(), appointment);
	}
	
	// argument for deleted ID
	public void deleteAppointment(Appointment appointment) {
		if (appointments.conatinsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Appointment ID not found");
		}
		appointments.remove(appointmentId);
	}
	
	// argument for not finding ID
	public void getAppointment(String appointmentId) {
		if (appointments.conatinsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Appointment ID not found");
		}
		return appointments.get(appointmentId);
	}
	
}
