//Briana Long
//CS320
//6/16/24
//
// Testing of Appointment class of ID, Date and description to ensure character length and appropriate date

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }
    
    @Test
    @DisplayName("Test for invalid appointment ID")
    public void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // a date in the future
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Description"));
    }

    @Test
    @DisplayName("Test for invalid Date")
    public void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // a date in the past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1234567890", pastDate, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1234567890", null, "Description"));
    }

    @Test
    @DisplayName("Test for invalid description")
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // a date in the future
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1234567890", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1234567890", futureDate, "This description is definitely longer than fifty characters which is not allowed!!!!"));
    }
}