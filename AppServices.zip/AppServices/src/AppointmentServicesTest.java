//Briana Long
//CS320
//6/16/24
//
// Testing of Appointment class for the adding and deleting of appointments

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    @DisplayName("Testing for date")
    public void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // a date in the future
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        appointmentService.addAppointment(appointment);

        assertEquals(appointment, appointmentService.getAppointment("1234567890"));
    }

    @Test
    @DisplayName("Test for duplicate Date")
    public void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // a date in the future
        Appointment appointment1 = new Appointment("1234567890", futureDate, "Description");
        Appointment appointment2 = new Appointment("1234567890", futureDate, "Description 2");

        appointmentService.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment2));
    }

    @Test
    @DisplayName("Test for deleted ")
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // a date in the future
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        appointmentService.addAppointment(appointment);

        appointmentService.deleteAppointment("1234567890");
        assertThrows(IllegalArgumentException.class, () -> appointmentService.getAppointment("1234567890"));
    }
}
