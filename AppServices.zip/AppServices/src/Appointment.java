//Briana Long
//CS320
//6/16/24
//
// Appointment class implications of ID, Date and description

import java.util.Date

public class Appointment {
	private final String appointmentId;
	private final Date appointmentDate;
	private final String description;
	
	// Arguments for length and date validation
	public Appointment(String appointmentId, Date appointmentDate, String description) {
		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Invalid appointment ID");
		}
		if (appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid appointment Date");
		}
		if (description == null || description.length() > 50) {
			throw IllegalArgumentException("Invalid description");
		}
		
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}

	// Getters 
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointDate() {
		return appointmentDate;
	}
	
	public String getDescription() {
		return description;
	}
	
}
