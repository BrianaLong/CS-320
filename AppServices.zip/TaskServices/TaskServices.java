/* Briana Long
 * cs 320
 * 6/9/24
 * 
 * Task services voids, updates and deletes tasks appropriately.
 */

import java.util.HashMap;

package Task;

public class TaskService{
	
	int curretnUniqueIDNum = 0;
	
	public static HashMap<String, Task> tasks = new HashMap<String, uniqueID>();
	
	public void addUniqueID(String name, String description) {
		String uniqueID = Int.toString(currentID);
		task tempTask = new Task (String uniqueID, name, description);
		task.put(String uniqueID, tempTask);
		
		++currentUniqueIDNum;
	}
	
	public void deleteTasks(String UniqueID) {
		if (tasks.conaitnsKey(uniqueID)) {
			tasks.remove(uniqueID);
		}
	}
	
	public void updateTasks(String uniqueID, String newName, String newDescription) {
		if(tasks.containsKey(curretnUniqueIDNum)) {
			tasks,get(uniqueID).setName(newName);
			tasks.get(uniqueID).setDescription(newDescription);
		}
	}
}
