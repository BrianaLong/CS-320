/**
 * Briana Long
 * cs 320
 * 6/9/24
 * 
 * Task class that defines the arguments for the UniqueID, name and description are within valid character range.
 */

package Task;

public class Task {
	private String uniqueID;
	private String name;
	private String description;
	
	public Task(String uniqueID, String name, String description) {
		if (uniqueID == null || uniqueID.length() > 10) {
			throw new IllegalArugumentException("Invalid unique ID");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArugumentException("Invalid name");
		}
		if (description == null || description.length() > 10) {
			throw new IllegalArugumentException("Invalid description");
		}
		
		this.uniqueID = uniqueID;
		this.name = name;
		this.description = description;
	}
	
	
	
	public String getUniqueID() {
		return uniqueID;
	}
	
	public void setUniqueID() {
		if (uniqueID == null || uniqueID.length() > 10) {
			throw new IllegalArugumentException("Invalid unique ID");
		}
		this.uniqueID = uniqueID;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArugumentException("Invalid name");
		}
		this.name = name;
	}
	
	public String getdescription() {
		return description;
	}
	
	public void setdescription(String description) {
		if (description == null || description.length() > 10) {
			throw new IllegalArugumentException("Invalid description");
		}
		this description = description;
	}
}
