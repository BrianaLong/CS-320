/* Briana Long
 * cs 320
 * 6/9/24
 * 
 * This is the test class for the Task Services class to ensure deletes, updates and duplicates are assessed.
 */

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


class TaskServiceTest {
	
	private TaskService taskService;
	
	@Before Each
	public void setup() {
		taskService = new TaskService();	
	}
	
	@Test
	@DisplayName("Test for duplicates")
    public void testAddTaskWithDuplicateId() {
        Task task1 = new Task("1", "Name1", "Description1");
        Task task2 = new Task("1", "Name2", "Description2");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    @DisplayName("Test Delete")
    public void testDeleteTask() {
        Task task = new Task("1", "Name1", "Description1");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    @DisplayName("Test to update Name")
    public void testUpdateTaskName() {
        Task task = new Task("1", "Name", "Description1");
        taskService.addTask(task);
        taskService.updateTaskName("1", "NewTaskName");
        assertEquals("NewTaskName", taskService.getTask("1").getName());
    }

    @Test
    @DisplayName("Test to update description")
    public void testUpdateTaskDescription() {
        Task task = new Task("1", "Name1", "Description1");
        taskService.addTask(task);
        taskService.updateTaskDescription("1", "NewDescription");
        assertEquals("NewDescription", taskService.getTask("1").getDescription());
    }

}