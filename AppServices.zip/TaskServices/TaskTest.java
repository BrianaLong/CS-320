/* Briana Long
 * cs 320
 * 6/9/24
 * 
 * This is the test class for the Task class to ensure the uniqueID, name, and description remain within the alloted amount of characters
 */

package TaskTest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TaskTest{ 
	
	@Test
	@DisplayName("uniqueID String that cannot be longer than 10 characters.")
	void testUniqueIDWithMoreThanTenCharacters() {
		Task task = new Task("Name", "Description");
		if(task.getUniqueID().length() > 10) {
			fail("UniqueID has more than 10 characters.");
		}
	}
	
	@Test
	@DisplayName("Name cannot have more than 20 characters.")
	void testNameWithMoreThanTwentyCharacters() {
		Task task = new Task("A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z.", "Description");
		if (task.getName().length() > 20) {
			fail("Name has more than 20 characters.");
		}
	}
	
	@Test
	@DisplayName("Name shall not be null")
	void testNameNotNull() {
		Task task = new Task (null, "Description");
		assertThrows(task.getName(), "Name was null.");
	}
	
	
	
	@Test
	@Display("Description cannot have more than 50 character")
	void testDescriptionWithMoreThanFiftyCharacters() {
		Task task = new Task("Name", "the early bird gets the worm,the early bird gets the worm. ");
		if (task.getdescription().length() > 50) {
			fail("Description has more than 50 characters.")
		}
	}
	
	
	@Test
	@Description ("Description shall not be null.")
	void testDescriptionNotNull() {
		Task task = new Task("Name", null);
		assertThrows(task.getDescription(), "Description was null.");
	}
}